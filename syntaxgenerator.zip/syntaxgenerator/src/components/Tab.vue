  <script>
  case 'REGULAR':
            switch(val['order_type']) {
              case 'MARKET':
              output +=  '"TT":"'+val['transition_type']+'","E":"'+val['exchange']+'","IT":"'+val['IT']+'","Q":"'+val['quantity']+'",'+quantitypercentage+'"OT":"'+val['order_type']+'","P":"'+val['product_type']+'","VL":"DAY"';
              break;
              case 'LIMIT':
              LTP = prtp(val['transition_type'],val['LTP'],val['LTPpercentage'],'-','+');
              output +=  '"TT":"'+val['transition_type']+'","E":"'+val['exchange']+'","IT":"'+val['IT']+'","Q":"'+val['quantity']+'",'+quantitypercentage+'"OT":"'+val['order_type']+'","LTP":"'+LTP+'","P":"'+val['product_type']+'","VL":"DAY"';
              break;
              case 'SLM':
              TRP = prtp(val['transition_type'],val['TRP'],val['TRPpercentage'],'+','-');
                   output +=  '"TT":"'+val['transition_type']+'","E":"'+val['exchange']+'","IT":"'+val['IT']+'","Q":"'+val['quantity']+'",'+quantitypercentage+'"OT":"'+val['order_type']+'","TRP":"'+TRP+'","P":"'+val['product_type']+'","VL":"DAY"';
              break;
              case 'SLL':
              LTP = prtp(val['transition_type'],val['LTP'],val['LTPpercentage'],'+','-'); TRP = prtp(val['transition_type'],val['TRP'],val['TRPpercentage'],'+','-');
                   output +=  '"TT":"'+val['transition_type']+'","E":"'+val['exchange']+'","IT":"'+val['IT']+'","Q":"'+val['quantity']+'",'+quantitypercentage+'"OT":"'+val['order_type']+'","LTP":"'+LTP+'","TRP":"'+TRP+'","P":"'+val['product_type']+'","VL":"DAY"';
              break;
            }
             </script>