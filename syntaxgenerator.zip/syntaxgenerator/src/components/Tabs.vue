<template>

<article>
    <header class="tabs">
<ul>
    <li v-for="(tab,index) in tabs" :key="index">
<div class="nav-item"
:class="{'nav-link active': tab.isActive}"
@click="selectTab(tab)"> 
{{tab.name}}
</div>
    </li>
</ul>
    </header>
    <section class="tab-details">
<slot></slot>
    </section>
</article>
</template>
<script>
export default {
data:()=>{
    return{
        tabs:[]
    }
},
methods:{
    selectTab(selectedTab){
        this.tabs.forEach(tab=>{
            tab.isActive=tab.name===selectedTab.name;
        })
    }
},
created(){
    this.tabs=this.$$children;
}
}
</script>