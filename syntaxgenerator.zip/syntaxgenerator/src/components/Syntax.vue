<template>
  <div class="body_wrapper">
    <header class="header_area">
      <nav class="navbar navbar-expand-lg menu_one menu_four">
        <div class="container custom_container p0">
          <a class="navbar-brand" href="https://nextlevelbot.com"
            ><img
              src="https://nextlevelbot.com/assests/img/logo.png"
              srcset="https://nextlevelbot.com/assests/img/logo.png 2x"
              alt="logo"
          /></a>
          <button
            class="navbar-toggler collapsed"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="menu_toggle">
              <span class="hamburger">
                <span></span>
                <span></span>
                <span></span>
              </span>
              <span class="hamburger-cross">
                <span></span>
                <span></span>
              </span>
            </span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav menu w_menu mr-auto ml-auto">
              <li class="nav-item">
                <a
                  class="nav-link"
                  href="https://nextlevelbot.com"
                  role="button"
                >
                  Home
                </a>
              </li>
              <li class="nav-item">
                <a
                  class="nav-link"
                  href="https://nextlevelbot.com/price"
                  role="button"
                >
                  Price
                </a>
              </li>
              <li class="nav-item dropdown submenu">
                <a class="nav-link" href="" role="button"> Indicator Store </a>
                <ul class="dropdown-menu">
                  <li class="nav-item">
                    <a
                      href="https://nextlevelbot.com/indicator_store"
                      class="nav-link"
                      >Indicator Store</a
                    >
                  </li>
                  <li class="nav-item">
                    <a
                      href="https://nextlevelbot.com/indicator_access"
                      class="nav-link"
                      >Nextlevelbot Indicator</a
                    >
                  </li>
                </ul>
              </li>
              <li class="nav-item">
                <a
                  class="nav-link"
                  href="https://nextlevelbot.com/betasyntax"
                  role="button"
                >
                  Syntax
                </a>
              </li>
              <li class="nav-item">
                <a
                  class="nav-link"
                  href="https://nextlevelbot.com/videos"
                  role="button"
                >
                  Videos
                </a>
              </li>
              <li class="nav-item dropdown submenu">
                <a class="nav-link" href="" role="button"> More ! </a>
                <ul class="dropdown-menu">
                  <li class="nav-item">
                    <a
                      class="nav-link"
                      href="https://nextlevelbot.com/aliceblue_symbol"
                      >Symbol</a
                    >
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="https://nextlevelbot.com/resource"
                      >Resources</a
                    >
                  </li>
                  <li class="nav-item">
                    <a
                      class="nav-link"
                      href="https://nextlevelbot.com/syntaxgenerator"
                      >Syntax Generator</a
                    >
                  </li>
                </ul>
              </li>
            </ul>
            <a
              class="btn_get btn_hover menu_cus"
              href="https://nextlevelbot.com/login"
              >Login In</a
            >
          </div>
        </div>
      </nav>
    </header>
    <section class="breadcrumb_area">
      <div class="container">
        <div class="breadcrumb_content text-center">
          <h1 class="f_p f_700 f_size_50 w_color l_height50 mb_20">
            Syntax Generator
          </h1>
        </div>
      </div>
    </section>
    <section class="faq_area bg_color sec_pad">
      <div class="container custom_container">
        <div class="row">
          <div class="col-lg-2 col-md-2 xb_card">
            <ul
              class="nav nav-tabs software_service_tab"
              id="myTab"
              role="tablist"
            >
              <li class="nav-item">
                <a
                  class="nav-link"
                  :class="{ active: active_el === 'FYERSV2' }"
                  @click="ActiveTab('FYERSV2')"
                  >Fyres Syntax</a
                >
              </li>
              <li class="nav-item">
                <a
                  class="nav-link"
                  :class="{ active: active_el === 'ALICEBLUE' }"
                  @click="ActiveTab('ALICEBLUE')"
                  >AliceBlue Syntax</a
                >
              </li>
            </ul>
          </div>
          <div class="col-lg-10">
            <div class="col-12 xb_card p-4" id="syntax_data">
            
               <div
class="buying-selling-group"
data-toggle="buttons"

>
<h5 class="mt-2 border-left">
  VARITEY
   <!-- <br/>
    <br/>
  <span>Test  {{MainButton}}</span> -->
  <span
    class="conditional text-danger"
    
    style="display: none"
  >
  </span>
</h5>
<label
  class="btn btn-default buying-selling mt-1 REGULAR_child" 
  :class="{ active: MainButton === 'REGULAR' }"
  @click="MainVaritey('REGULAR')"
>
  <span
    class="buying-selling-word"    
    >REGULAR</span
  >
 
</label>
<label
  class="btn btn-default buying-selling mt-1 CO_child"
  :class="{ active: MainButton === 'CO' }"
  @click="MainVaritey('CO')"
>
  <span class="buying-selling-word" 
    >CO</span
  >
</label>
<label
  class="btn btn-default buying-selling mt-1 BO_child"
  :class="{ active: MainButton === 'BO' }" @click="MainVaritey('BO')"
  
>
  <span class="buying-selling-word" 
    >BO</span
  >
</label>
<label
  class="btn btn-default buying-selling mt-1 CANCEL_child"
  :class="{ active: MainButton === 'CANCEL' }" @click="MainVaritey('CANCEL')"
  
>
  <span
    class="buying-selling-word"
    
    >CANCEL ORDER</span
  >
</label>
<label
  class="btn btn-default buying-selling mt-1 CLOSE_child"
  :class="{ active: MainButton === 'CLOSE' }"   @click="MainVaritey('CLOSE')"
  
>
  <span
    class="buying-selling-word"
  
    >EXIT ORDER</span
  >
</label>
<label
  class="btn btn-default buying-selling mt-1 AS_child"
  :class="{ active: MainButton === 'AS' }" @click="MainVaritey('AS')"
  
>
  <span class="buying-selling-word" 
    >ALTERNATIVE SYMBOLS</span
  >
</label>
<label
  class="btn btn-default buying-selling mt-1 ALGOCOBO_child"
  :class="{ active: MainButton === 'ALGOCOBO' }" @click="MainVaritey('ALGOCOBO')"
  
>
  <span
    class="buying-selling-word"
    
    >FULLY ALGO</span
  >
</label>
<label
  class="btn btn-default buying-selling mt-1 STRATEGY_child"
  :class="{ active: MainButton === 'STRATEGY' }" @click="MainVaritey('STRATEGY')"
  
>
  <span
    class="buying-selling-word"
    
    >STRATEGY</span
  >
</label>
<label
  class="btn btn-default buying-selling mt-1 STRIKEPRICE_child"
  :class="{ active: MainButton === 'STRIKEPRICE' }" @click="MainVaritey('STRIKEPRICE')"
  
>
  <span
    class="buying-selling-word"
    
    >AUTO STRIKE PRICE</span
  >
</label>
</div>

 <div v-if="active_el ==='FYERSV2'">
        
           <div class="buying-selling-group conditional " data-toggle="buttons" v-if="active_el ==='FYERSV2' && MainButton ==='ALGOCOBO' ||MainButton==='STRATEGY' ||MainButton==='STRIKEPRICE'" >
                            <h5 class="mt-2 border-left">ORDER TYPE </h5>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 FULLYMIS_child" @click="AutomationChange('FULLYMIS')"  :class="{ active: auto_mation === 'FULLYMIS' }">
                        
                        <span class="buying-selling-word">REGULAR</span>
                    </label>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 FULLYBO_child" @click="AutomationChange('FULLYBO')" :class="{ active: auto_mation === 'FULLYBO' }">
                        
                        <span class="buying-selling-word">BO</span>
                    </label>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 FULLYCO_child " @click="AutomationChange('FULLYCO')" :class="{ active: auto_mation === 'FULLYCO' }">
                        
                        <span class="buying-selling-word">CO</span>
                    </label>
        </div>  
         <div class="buying-selling-group conditional " data-toggle="buttons" v-if="active_el ==='FYERSV2' && MainButton==='STRIKEPRICE' && auto_mation!=''">
                            <h5 class="mt-2 border-left">WITH CLOSE OR WITHOUT CLOSE </h5>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 without_close_child" @click="Close_without_Type('without_close')" :class="{ active: Close_without_Value === 'without_close' }">
                        
                        <span class="buying-selling-word">WITHOUT CLOSE</span>
                    </label>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 " @click="Close_without_Type('with_close')" :class="{ active: Close_without_Value === 'with_close' }">
          
                        <span class="buying-selling-word">WITH CLOSE</span>
                    </label>
                  </div>  
                  <div class="buying-selling-group conditional " data-toggle="buttons" v-if="active_el ==='FYERSV2' && MainButton==='STRIKEPRICE' && auto_mation!='' && Close_without_Value!=''">
                            <h5 class="mt-2 border-left">CAL PUT SELECTION </h5>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 PE_child" @click="CAL_PUT_SELECTION('PE')"  :class="{ active: cal_put === 'PE' }">
                        
                        <span class="buying-selling-word">PE</span>
                    </label>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 CE_child "  @click="CAL_PUT_SELECTION('CE')"  :class="{ active: cal_put === 'CE' }">
                        
                        <span class="buying-selling-word">CE</span>
                    </label>
                        </div> 


   <div class="buying-selling-group conditional " v-if="active_el ==='FYERSV2' && MainButton ==='REGULAR' ||MainButton==='CO'|| MainButton==='BO' ||MainButton==='CANCEL' ||MainButton==='CLOSE' ||MainButton==='AS'|| ((MainButton ==='ALGOCOBO' || MainButton==='STRATEGY') && auto_mation!='') ||(MainButton==='STRIKEPRICE' && auto_mation!='' && Close_without_Value!='' && cal_put!='')" >
        <h5 class="mt-2 border-left">TRADING SYMBOL Ex. NSE:SBIN-EQ 
       
          <span v-if="MainButton === 'CANCEL' || MainButton === 'CLOSE' " class="conditional text-danger" > ( Optional ) </span>
          </h5>
                  <input
                    type="text"
                    name="tradingsymbol"
                    v-model="tradingsymbol"
                    placeholder="tradingsymbol"
                    id="tradingsymbol"
                  />
                </div>
            
                <div
                  class="buying-selling-group conditional"
                  
                  v-if="active_el ==='FYERSV2' && (tradingsymbol != '' && tradingsymbol) || ( MainButton=== 'CLOSE')"
                   >
                  <h5 class="mt-2 border-left">Quantity 
                     <span class="conditional text-danger" v-if="MainButton==='CLOSE'  || (MainButton  ==='AS' && tradingsymbol!='' )"> ( Optional ) </span>
  
                  </h5>
                  <input type="number" name="quantity" v-model="quantity" />
                  <input
                    type="checkbox"
                    name="quantitypercentage"
                    v-model="quantitypercentage"
                    @change="QuantityPercentageChange($event)"
                    class="percentage"
                  />
                  % Percentage
                </div>
                <div
                  class="buying-selling-group conditional"
                  data-toggle="buttons"
                  v-if="active_el ==='FYERSV2' && quantitypercentage === '%' && MainButton  !='CLOSE' && MainButton  !='AS'"
                >
                    <h5 class="mt-2 border-left">
                    FUNDS
                    <span
                      class="conditional text-danger"
                      
                      style="display: none"
                    >
                    </span>
                  </h5>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 EQUITY_child"
                    :class="{ active: Fund === 'EQUITY' }"
                  >
                    <span
                      class="buying-selling-word"
                      @click="FundType('EQUITY')"
                      >EQUITY</span
                    >
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 COMMODITY_child"
                    :class="{ active: Fund === 'COMMODITY' }"
                  >
                    <span
                      class="buying-selling-word"
                      @click="FundType('COMMODITY')"
                      >COMMODITY</span
                    >
                  </label>
                </div>

                <div class="buying-selling-group conditional" v-if="active_el ==='FYERSV2'&& Fund != ''">
                  <h5 class="mt-2 border-left">LEVERAGE</h5>
                  <input
                    type="number"
                    name="LEVERAGE"
                    placeholder="LEVERAGE"
                    v-model="LEVERAGE"
                  />
                </div>
                <div
                  class="buying-selling-group conditional"
                  v-if="active_el ==='FYERSV2' && LEVERAGE != ''   || ( (MainButton  ==='CLOSE' || MainButton  === 'AS') && quantitypercentage==='%' ) "
                >
                  <h5 class="mt-2 border-left">
                    PER LOT SIZE
                    <span v-if="Fund != ''" class="conditional text-danger"> ( Optional ) </span>
                  </h5>
                  <input
                    type="number"
                     v-model="PER_LOT_SIZE"
                    name="per_lot_size"
                    placeholder="PER_LOT_SIZE"
                    id="PER_LOT_SIZE"
                  />
                </div>
                
                <div
                  class="buying-selling-group conditional"
                 v-if="active_el ==='FYERSV2' && (quantity!='' && MainButton!='STRATEGY') || (MainButton === 'CANCEL' || MainButton === 'CLOSE') ||(tradingsymbol!='' && MainButton === 'AS')"
                  data-toggle="buttons"
                >
                  <h5 class="mt-2 border-left">TRANSITION TYPE 
<span v-if="(MainButton === 'CANCEL' || MainButton === 'CLOSE' || MainButton === 'AS')" class="conditional text-danger" > ( Optional ) </span>

                  </h5>
                  <label  @click="TransactionType('BUY')"
                    class="btn btn-default drop_action_class buying-selling mt-1 BUY_child"
                    :class="{ active: Transaction === 'BUY' }"
                  >
                    <span
                      class="buying-selling-word"
                     
                      >BUY</span
                    >
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 SELL_child"
                    :class="{ active: Transaction === 'SELL' }"
                  >
                    <span
                      class="buying-selling-word"
                      @click="TransactionType('SELL')"
                      >SELL</span
                    >
                  </label>
                </div>

                <div
                  class="buying-selling-group conditional"
                  data-toggle="buttons"
                  v-if="active_el ==='FYERSV2' && ((MainButton === 'REGULAR' || MainButton === 'CO' || MainButton === 'BO' || MainButton==='STRIKEPRICE') && Transaction != '') || (MainButton ==='ALGOCOBO' && auto_mation!='' && Transaction!='') ||(MainButton==='STRATEGY' && auto_mation!='' && tradingsymbol!='' && quantity!='') " 
                >
                  <h5 class="mt-2 border-left">ORDER TYPE</h5>
                  <label  @click="OrderTypeChange('MARKET')"
                    class="btn btn-default drop_action_class buying-selling mt-1 MARKET_child"
                    :class="{ active: OrderType === 'MARKET' }"
                    v-if="(MainButton === 'REGULAR' || MainButton === 'CO' || MainButton === 'BO' || MainButton==='STRIKEPRICE' || MainButton==='ALGOCOBO' || (MainButton==='STRATEGY' && auto_mation!='' && tradingsymbol!='' && quantity!='')) " 
                  >
                    <span
                      class="buying-selling-word"
                     
                      >Market</span
                    >
                  </label>
                  <label @click="OrderTypeChange('LIMIT')"
                    class="btn btn-default drop_action_class buying-selling mt-1 LIMIT_child"
                    :class="{ active: OrderType === 'LIMIT' }"
                    v-if="(MainButton === 'REGULAR' || MainButton === 'CO' || MainButton === 'BO' || MainButton==='STRIKEPRICE') " 
                  >
                    <span
                      class="buying-selling-word"
                      
                      >LIMIT</span
                    >
                  </label>
                  <label  @click="OrderTypeChange('SLM')"
                    class="btn btn-default drop_action_class buying-selling mt-1 SLM_child"
                    :class="{ active: OrderType === 'SLM' }"
                    v-if="(MainButton === 'REGULAR' || MainButton === 'CO' || MainButton === 'BO')"
                  >
                    <span
                      class="buying-selling-word"
                     
                      >SLM</span
                    >
                  </label>
                  <label @click="OrderTypeChange('SLL')"
                    class="btn btn-default drop_action_class buying-selling mt-1 SLL_child"
                    :class="{ active: OrderType === 'SLL' }"
                    v-if="(MainButton === 'REGULAR' || MainButton === 'CO' || MainButton === 'BO')"
                  >
                    <span
                      class="buying-selling-word"
                      
                      >SLL</span
                    >
                  </label>
                </div>
                <div class="row mt-3">
                    <div class="col-4 TRP_child_box conditional" v-if="active_el ==='FYERSV2' && (MainButton === 'REGULAR'  &&  (OrderType === 'SLM' || OrderType === 'SLL')) || (MainButton  == 'CO' &&(OrderType === 'SLM' || OrderType === 'SLL' ) )  || (MainButton  == 'BO' &&(OrderType === 'SLM' || OrderType === 'SLL' ) )" >
                
                    <h5 class="mt-2 border-left">TRIGGER PRICE</h5>
                    <input
                      type="number"
                      name="TRP"
                      id="TRP"
                      v-model="TRP"
                      class="text-box"
                      placeholder="Ex. 1"
                      value="1"
                    />
                    <input
                      type="checkbox"
                      name="TRPpercentage"
                      value="%"
                      @change="TRPpercentageChange($event)"
                      class="percentage"
                    />
                    % Percentage
                  </div>
                  <div
                    class="col-4 LTP_child_box conditional"
                   v-if="(MainButton === 'REGULAR'  &&  (OrderType === 'LIMIT' || OrderType === 'SLL')) || (MainButton  == 'CO' &&(OrderType === 'LIMIT' || OrderType === 'SLL' ) )  || (MainButton  == 'BO' &&(OrderType === 'LIMIT' || OrderType === 'SLL' ) ) || (MainButton  == 'STRIKEPRICE' &&(OrderType === 'LIMIT' ) )" 
                  >
                    <h5 class="mt-2 border-left">LTP (LIMIT)</h5>
                    <input
                      type="number"
                      name="LTP"
                      id="LTP"
                      class="text-box"
                      v-model="LTP"
                      placeholder="Ex. 1"
                      value="1"
                    />
                    <input
                      type="checkbox"
                      name="LTPpercentage"
                      value="%"
                      @change="LTPpercentageChange($event)"
                      class="percentage"
                    />
                    % Percentage
                  </div>
                  <div
                    class="col-4 SL_child_box conditional"
                    v-if="(( MainButton  ==='STRIKEPRICE' && auto_mation ===  'FULLYBO' &&quantity!='')||(MainButton  ==='CO' && (OrderType === 'MARKET' ||OrderType === 'LIMIT' ||OrderType === 'SLM' ||OrderType === 'SLL')) || (MainButton  ==='BO' && (OrderType === 'MARKET' ||OrderType === 'LIMIT' ||OrderType === 'SLM' ||OrderType === 'SLL')) || ( MainButton == 'ALGOCOBO' && (auto_mation =='FULLYBO' |auto_mation =='FULLYCO') && OrderType!='' ))" 
                  >
                    <h5 class="mt-2 border-left">STOP LOSS</h5>
                    <input
                      type="number"
                      name="SL"
                      id="SL"
                      class="text-box"
                      v-model="SL"
                      placeholder="Ex. 1"
                      value="1"
                    />
                    <input
                      type="checkbox"
                      name="SLpercentage"
                      value="%"
                      class="percentage"
                      @change="SLpercentageChange($event)"
                    />
                    % Percentage
                  </div>
                 
                  <div
                    class="col-4 TP_child_box conditional"
                    v-if="(( MainButton  ==='STRIKEPRICE' && auto_mation ===  'FULLYBO' &&quantity!='')||(MainButton  !='CO' &&  MainButton  !='STRIKEPRICE' && OrderType ===  'LIMIT' ) || (MainButton  ==='BO' && (OrderType === 'MARKET' ||OrderType === 'LIMIT' ||OrderType === 'SLM' ||OrderType === 'SLL')) || ( MainButton == 'ALGOCOBO' && auto_mation =='FULLYBO' && OrderType!='' ))" 
                  >
                    <h5 class="mt-2 border-left">TARGET</h5>
                    <input
                      type="number"
                      name="TP"
                      id="TP"
                      v-model="TP"
                      class="text-box"
                      placeholder="Ex. 1"
                      value="1"
                    />
                    <input
                      type="checkbox"
                      name="TPpercentage"
                      @change="TPpercentageChange($event)"
                      value="%"
                      class="percentage"
                    />
                    % Percentage
                  </div>
                </div>
                <div
                  class="buying-selling-group conditional"
                  data-toggle="buttons"
                 v-if="active_el ==='FYERSV2' && (MainButton  == 'REGULAR' && OrderType ) || ( MainButton  == 'CANCEL' ||  MainButton  == 'CLOSE' || ( MainButton  == 'AS' && tradingsymbol ) ) || (auto_mation == 'MIS'  && OrderType) || (MainButton == 'CLOSE' && quantity) || (MainButton==='STRATEGY' && auto_mation!='' && tradingsymbol!='' && quantity!='') || ( MainButton==='STRIKEPRICE' && auto_mation!='FULLYBO' && auto_mation!='FULLYCO' && auto_mation!='' && Close_without_Value!='' && cal_put!='' && OrderType!='') || ( MainButton == 'ALGOCOBO' && auto_mation =='FULLYMIS' && OrderType!='' )"
                >
                  <h5 class="mt-2 border-left">PRODUCT
                      <span v-if="MainButton === 'CANCEL' || MainButton==='AS'" class="conditional text-danger" > ( Optional ) </span>
                  </h5>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 INTRADAY_child conditional"
                    :class="{ active: Producttype === 'INTRADAY' }" @click="ProducttypeC('INTRADAY')"
                  >
                    <span
                      class="buying-selling-word"
                      
                      >INTRADAY</span
                    >
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 CNC_child conditional"
                    :class="{ active: Producttype === 'CNC' }" @click="ProducttypeC('CNC')"
                  >
                    <span
                      class="buying-selling-word"
                      
                      >CNC</span
                    >
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 MARGIN_child conditional"
                    :class="{ active: Producttype === 'MARGIN' }"  @click="ProducttypeC('MARGIN')"
                  >
                    <span
                      class="buying-selling-word"
                     
                      >MARGIN</span
                    >
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 BO_child conditional"
                   :class="{ active: Producttype === 'BO' }"
                     v-if="(MainButton  == 'CANCEL' || MainButton  == 'CLOSE'|| MainButton  == 'AS')"
                  >
                    <input
                      type="radio"
                      name="product_type"
                      value="BO"
                      id="BO"
                    />
                    <span class="buying-selling-word"  @click="ProducttypeC('BO')">BO</span>
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 CO_child conditional"
                   v-if="(MainButton  == 'CANCEL' || MainButton  == 'CLOSE'|| MainButton  == 'AS')"
                  :class="{ active: Producttype === 'CO' }"
                  >
                    <input
                      type="radio"
                      name="product_type"
                      value="CO"
                      id="CO"
                      @click="ProducttypeC('CO')"
                    />
                    <span class="buying-selling-word" @click="ProducttypeC('CO')">CO</span>
                  </label>
                </div>
                <div
                  class="buying-selling-group conditional"
                  v-if="active_el ==='FYERSV2' && ( MainButton  ==='STRIKEPRICE' && auto_mation != '' && OrderType!=''  &&quantity!='') " 
                >
                  <h5 class="mt-2 border-left">
                    NEAR BY
                    <span
                      class="conditional text-danger"
                      
                      style="display: none"
                    >
                    </span>
                  </h5>
                  <input
                    type="number"
                    name="near_by"
                    placeholder="NEARBY"
                    v-model="NEARBY"
                    id="NEARBY"
                  />
                </div>
                <div
                  class="buying-selling-group conditional"
                  v-if="active_el ==='FYERSV2' && NEARBY!=''"
                  
                >
                  <h5 class="mt-2 border-left">
                    CAL
                    <span
                      class="conditional text-danger"
                      
                     
                    >
                    </span>
                  </h5>
                  <input type="number" v-model="NEARBYCAL" name="cal" placeholder="cal" id="cal" />
                </div>
                <div
                  class="buying-selling-group conditional"
                  data-toggle="buttons"
                  v-if="active_el ==='FYERSV2' && NEARBYCAL!=''"
                 
                >
                  <h5 class="mt-2 border-left">
                    PLUS AND MINUS
                    <span
                      class="conditional text-danger"
                      
                      style="display: none"
                    >
                    </span>
                  </h5>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 +_child"
                    :class="{ active: cal_plus_minus === '+' }" @click="cal_plus_minusType('+')"
                  >
                    <input
                      type="radio"
                      v-model="cal_plus_minus"
                      name="cal_plus_minus"
                      value="+"
                      id="+"
                    />
                    <span class="buying-selling-word">+</span>
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 -_child"
                    :class="{ active: cal_plus_minus === '-' }" @click="cal_plus_minusType('-')"
                  >
                    <input
                      type="radio"
                      name="cal_plus_minus"
                      value="-"
                      v-model="cal_plus_minus"
                      id="-"
                    />
                    <span class="buying-selling-word">-</span>
                  </label>
                </div>
            </div>
            <!-- ***************ALICEBLUE************** -->
            <div v-else-if="active_el==='ALICEBLUE'">
                <div class="buying-selling-group conditional " data-toggle="buttons" v-if="MainButton ==='ALGOCOBO' ||MainButton==='STRATEGY' ||MainButton==='STRIKEPRICE'" >
                            <h5 class="mt-2 border-left">ORDER TYPE </h5>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 FULLYMIS_child" @click="AutomationChange('FULLYMIS')"  :class="{ active: auto_mation === 'FULLYMIS' }">
                        
                        <span class="buying-selling-word">REGULAR</span>
                    </label>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 FULLYBO_child" @click="AutomationChange('FULLYBO')" :class="{ active: auto_mation === 'FULLYBO' }">
                        
                        <span class="buying-selling-word">BO</span>
                    </label>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 FULLYCO_child " @click="AutomationChange('FULLYCO')" :class="{ active: auto_mation === 'FULLYCO' }">
                        
                        <span class="buying-selling-word">CO</span>
                    </label>
        </div>
         <div class="buying-selling-group conditional " data-toggle="buttons" v-if=" MainButton==='STRIKEPRICE' && auto_mation!=''">
                            <h5 class="mt-2 border-left">WITH CLOSE OR WITHOUT CLOSE </h5>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 without_close_child" @click="Close_without_Type('without_close')" :class="{ active: Close_without_Value === 'without_close' }">
                        
                        <span class="buying-selling-word">WITHOUT CLOSE</span>
                    </label>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 " @click="Close_without_Type('with_close')" :class="{ active: Close_without_Value === 'with_close' }">
          
                        <span class="buying-selling-word">WITH CLOSE</span>
                    </label>
                  </div>  
                  <div class="buying-selling-group conditional " data-toggle="buttons" v-if="  MainButton==='STRIKEPRICE' && auto_mation!='' && Close_without_Value!=''">
                            <h5 class="mt-2 border-left">CAL PUT SELECTION </h5>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 PE_child" @click="CAL_PUT_SELECTION('PE')"  :class="{ active: cal_put === 'PE' }">
                        
                        <span class="buying-selling-word">PE</span>
                    </label>
                            <label class="btn btn-default drop_action_class buying-selling mt-1 CE_child "  @click="CAL_PUT_SELECTION('CE')"  :class="{ active: cal_put === 'CE' }">
                        
                        <span class="buying-selling-word">CE</span>
                    </label>
                        </div> 
            <div class="buying-selling-group conditional " v-if=" MainButton ==='REGULAR' || MainButton ==='CO' || MainButton ==='BO' || MainButton  ==='CANCEL' || MainButton  === 'CLOSE' || MainButton  === 'AS' || (MainButton==='ALGOCOBO' &&auto_mation!='' ||  MainButton==='STRATEGY' &&auto_mation!='' ) ||(MainButton==='STRIKEPRICE' &&auto_mation!='' && cal_put!='' )" >
            <h5 class="mt-2 border-left">{{MainButton ==='AS' || MainButton==='STRIKEPRICE'?'TRADING SYMBOL Ex. BANKNIFTY':'INSTRUMENT TOKEN Ex.3045A' }}  
              <span class="conditional text-danger" v-if="MainButton  ==='CANCEL' || MainButton  === 'CLOSE'" > ( Optional ) </span>
              </h5>
                                <input type="text" name="IT"  class="" v-model="IT">
                                            </div>
       <div class="buying-selling-group conditional " data-toggle="buttons" v-if="IT && MainButton  !='CANCEL' && MainButton  != 'CLOSE'" >
            <h5 class="mt-2 border-left">exchange <span class="conditional text-danger" >  </span></h5>
                                    <label class="btn btn-default drop_action_class buying-selling mt-1 NSE_child " @click="exchangeClick('NSE')" :class="{ active: exchange === 'NSE' }" >
                        
                        <span class="buying-selling-word">NSE</span>
                    </label>
                                    <label class="btn btn-default drop_action_class buying-selling mt-1 BSE_child  "  @click="exchangeClick('BSE')" :class="{ active: exchange === 'BSE' }">
 
                        <span class="buying-selling-word">BSE</span>
                    </label>
                                    <label class="btn btn-default drop_action_class buying-selling mt-1 BFO_child  " @click="exchangeClick('BFO')" :class="{ active: exchange === 'BFO' }">
 
                        <span class="buying-selling-word">BFO</span>
                    </label>
                                    <label class="btn btn-default drop_action_class buying-selling mt-1 NFO_child  " @click="exchangeClick('NFO')" :class="{ active: exchange === 'NFO' }">
                
                        <span class="buying-selling-word">NFO</span>
                    </label>
                                    <label class="btn btn-default drop_action_class buying-selling mt-1 MCX_child  " @click="exchangeClick('MCX')" :class="{ active: exchange === 'MCX' }">
                        <input type="radio" name="exchange" value="MCX" id="MCX">
                        <span class="buying-selling-word">MCX</span>
                    </label>
                                    <label class="btn btn-default drop_action_class buying-selling mt-1 CDS_child  " @click="exchangeClick('CDS')" :class="{ active: exchange === 'CDS' }">
 
                        <span class="buying-selling-word">CDS</span>
                    </label>
        </div>
           <div
                  class="buying-selling-group conditional"
                  
                  v-if="(IT != '' &&  exchange!='') || ( MainButton=== 'CLOSE')"
                   >
                  <h5 class="mt-2 border-left">Quantity 
                     <span class="conditional text-danger" v-if="MainButton==='CLOSE'  || (MainButton  ==='AS' && IT!='' )"> ( Optional ) </span>
  
                  </h5>
                  <input type="number" name="quantity" v-model="quantity" />
                  <input
                    type="checkbox"
                    name="quantitypercentage"
                    v-model="quantitypercentage"
                    @change="QuantityPercentageChange($event)"
                    class="percentage"
                  />
                  % Percentage
                </div>
                 <div
                  class="buying-selling-group conditional"
                  data-toggle="buttons"
                  v-if="quantitypercentage === '%' && MainButton  !='CLOSE' && MainButton  !='AS'"
                >
                    <h5 class="mt-2 border-left">
                    FUNDS
                    <span
                      class="conditional text-danger"
                      
                      style="display: none"
                    >
                    </span>
                  </h5>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 EQUITY_child"
                    :class="{ active: Fund === 'EQUITY' }"
                  >
                    <span
                      class="buying-selling-word"
                      @click="FundType('EQUITY')"
                      >EQUITY</span
                    >
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 COMMODITY_child"
                    :class="{ active: Fund === 'COMMODITY' }"
                  >
                    <span
                      class="buying-selling-word"
                      @click="FundType('COMMODITY')"
                      >COMMODITY</span
                    >
                  </label>
                </div>

                <div class="buying-selling-group conditional" v-if="Fund != ''">
                  <h5 class="mt-2 border-left">LEVERAGE</h5>
                  <input
                    type="number"
                    name="LEVERAGE"
                    placeholder="LEVERAGE"
                    v-model="LEVERAGE"
                  />
                </div>
                <div
                  class="buying-selling-group conditional"
                  v-if="LEVERAGE != ''   || ( (MainButton  ==='CLOSE' || MainButton  === 'AS') && quantitypercentage==='%' ) "
                >
                  <h5 class="mt-2 border-left">
                    PER LOT SIZE
                    <span v-if="Fund != ''" class="conditional text-danger"> ( Optional ) </span>
                  </h5>
                  <input
                    type="number"
                     v-model="PER_LOT_SIZE"
                    name="per_lot_size"
                    placeholder="PER_LOT_SIZE"
                    id="PER_LOT_SIZE"
                  />
                </div>
                 <div
                  class="buying-selling-group conditional"
                 v-if="(quantity!='' && MainButton!='STRATEGY') || (MainButton === 'CANCEL' || MainButton === 'CLOSE') ||(IT!='' && MainButton === 'AS')"
                  data-toggle="buttons"
                >
                  <h5 class="mt-2 border-left">TRANSITION TYPE 
<span v-if="(MainButton === 'CANCEL' || MainButton === 'CLOSE' || MainButton === 'AS')" class="conditional text-danger" > ( Optional ) </span>

                  </h5>
                  <label  @click="TransactionType('BUY')"
                    class="btn btn-default drop_action_class buying-selling mt-1 BUY_child"
                    :class="{ active: Transaction === 'BUY' }"
                  >
                    <span
                      class="buying-selling-word"
                     
                      >BUY</span
                    >
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 SELL_child"
                    :class="{ active: Transaction === 'SELL' }"
                  >
                    <span
                      class="buying-selling-word"
                      @click="TransactionType('SELL')"
                      >SELL</span
                    >
                  </label>
                </div>
                 <div
                  class="buying-selling-group conditional"
                  data-toggle="buttons"
                  v-if="((MainButton === 'REGULAR' || MainButton === 'CO' || MainButton === 'BO' || MainButton==='STRIKEPRICE') && Transaction != '') || (MainButton ==='ALGOCOBO' && auto_mation!='' && Transaction!='') ||(MainButton==='STRATEGY' && auto_mation!='' && IT!='' && quantity!='') " 
                >
                  <h5 class="mt-2 border-left">ORDER TYPE</h5>
                  <label  @click="OrderTypeChange('MARKET')"
                    class="btn btn-default drop_action_class buying-selling mt-1 MARKET_child"
                    :class="{ active: OrderType === 'MARKET' }"
                    v-if="(MainButton === 'REGULAR' || MainButton === 'CO' || MainButton === 'BO' || MainButton==='STRIKEPRICE' || MainButton==='ALGOCOBO' || (MainButton==='STRATEGY' && auto_mation!='' && IT!='' && quantity!='')) " 
                  >
                    <span
                      class="buying-selling-word"
                     
                      >Market</span
                    >
                  </label>
                  <label @click="OrderTypeChange('LIMIT')"
                    class="btn btn-default drop_action_class buying-selling mt-1 LIMIT_child"
                    :class="{ active: OrderType === 'LIMIT' }"
                    v-if="(MainButton === 'REGULAR' || MainButton === 'CO' || MainButton === 'BO' || MainButton==='STRIKEPRICE') " 
                  >
                    <span
                      class="buying-selling-word"
                      
                      >LIMIT</span
                    >
                  </label>
                  <label  @click="OrderTypeChange('SLM')"
                    class="btn btn-default drop_action_class buying-selling mt-1 SLM_child"
                    :class="{ active: OrderType === 'SLM' }"
                    v-if="(MainButton === 'REGULAR'  &&(MainButton != 'CO' || MainButton != 'BO'))"
                  >
                    <span
                      class="buying-selling-word"
                     
                      >SLM</span
                    >
                  </label>
                  <label @click="OrderTypeChange('SLL')"
                    class="btn btn-default drop_action_class buying-selling mt-1 SLL_child"
                    :class="{ active: OrderType === 'SLL' }"
                    v-if="(MainButton === 'REGULAR' || (MainButton != 'CO'  && MainButton!='ALGOCOBO' && MainButton!='STRATEGY' && MainButton!='STRIKEPRICE') || MainButton === 'BO')"
                  >
                    <span
                      class="buying-selling-word"
                      
                      >SLL</span
                    >
                  </label>
                </div>
   <div class="row mt-3">
                    <div class="col-4 TRP_child_box conditional" v-if="(MainButton === 'REGULAR'  &&  (OrderType === 'SLM' || OrderType === 'SLL')) || (MainButton  == 'CO' &&(OrderType === 'SLM' || OrderType === 'SLL' ) )  || (MainButton  == 'BO' &&(OrderType === 'SLM' || OrderType === 'SLL' ) )" >
                
                    <h5 class="mt-2 border-left">TRIGGER PRICE</h5>
                    <input
                      type="number"
                      name="TRP"
                      id="TRP"
                      v-model="TRP"
                      class="text-box"
                      placeholder="Ex. 1"
                      value="1"
                    />
                    <input
                      type="checkbox"
                      name="TRPpercentage"
                      value="%"
                      @change="TRPpercentageChange($event)"
                      class="percentage"
                    />
                    % Percentage
                  </div>
                  <div
                    class="col-4 LTP_child_box conditional"
                   v-if="(MainButton === 'REGULAR'  &&  (OrderType === 'LIMIT' || OrderType === 'SLL')) || (MainButton  == 'CO' &&(OrderType === 'LIMIT' || OrderType === 'SLL' ) )  || (MainButton  == 'BO' &&(OrderType === 'LIMIT' || OrderType === 'SLL' ) ) || (MainButton  == 'STRIKEPRICE' &&(OrderType === 'LIMIT' ) )" 
                  >
                    <h5 class="mt-2 border-left">LTP (LIMIT)</h5>
                    <input
                      type="number"
                      name="LTP"
                      id="LTP"
                      class="text-box"
                      v-model="LTP"
                      placeholder="Ex. 1"
                      value="1"
                    />
                    <input
                      type="checkbox"
                      name="LTPpercentage"
                      value="%"
                      @change="LTPpercentageChange($event)"
                      class="percentage"
                    />
                    % Percentage
                  </div>
                  <div
                    class="col-4 SL_child_box conditional"
                    v-if="(( MainButton  ==='STRIKEPRICE' && (auto_mation ===  'FULLYBO' || auto_mation ===  'FULLYCO') &&quantity!='') ||( MainButton  ==='STRATEGY' && auto_mation !='' &&quantity!='' && OrderType==='MARKET')||(MainButton  ==='CO' && (OrderType === 'MARKET' ||OrderType === 'LIMIT' ||OrderType === 'SLM' ||OrderType === 'SLL')) || (MainButton  ==='BO' && (OrderType === 'MARKET' ||OrderType === 'LIMIT' ||OrderType === 'SLM' ||OrderType === 'SLL')) || ( MainButton == 'ALGOCOBO' && (auto_mation =='FULLYBO' |auto_mation =='FULLYCO') && OrderType!='' ))" 
                  >
                    <h5 class="mt-2 border-left">STOP LOSS</h5>
                    <input
                      type="number"
                      name="SL"
                      id="SL"
                      class="text-box"
                      v-model="SL"
                      placeholder="Ex. 1"
                      value="1"
                    />
                    <input
                      type="checkbox"
                      name="SLpercentage"
                      value="%"
                      class="percentage"
                      @change="SLpercentageChange($event)"
                    />
                    % Percentage
                  </div>
                 <!-- ***************TARGET*********** -->
                  <div
                    class="col-4 TP_child_box conditional"
                    v-if="( ( MainButton  ==='STRATEGY' && auto_mation ==='FULLYBO' &&quantity!='' && OrderType==='MARKET')|| ( MainButton  ==='STRIKEPRICE' && auto_mation ===  'FULLYBO' &&quantity!='')||(MainButton  !='CO' &&  MainButton  !='STRIKEPRICE' && OrderType ===  'LIMIT' ) || (MainButton  ==='BO' && (OrderType === 'MARKET' ||OrderType === 'LIMIT' ||OrderType === 'SLM' ||OrderType === 'SLL')) || ( MainButton == 'ALGOCOBO' && auto_mation =='FULLYBO' && OrderType!='' ))" 
                  >
                    <h5 class="mt-2 border-left">TARGET</h5>
                    <input
                      type="number"
                      name="TP"
                      id="TP"
                      v-model="TP"
                      class="text-box"
                      placeholder="Ex. 1"
                      value="1"
                    />
                    <input
                      type="checkbox"
                      name="TPpercentage"
                      @change="TPpercentageChange($event)"
                      value="%"
                      class="percentage"
                    />
                    % Percentage
                  </div>
                   <!-- ***************TARGET*********** -->
                </div>
                 <div
                  class="buying-selling-group conditional"
                  data-toggle="buttons"
                 v-if="(MainButton  == 'REGULAR' && OrderType ) || ( MainButton  == 'CANCEL' ||  MainButton  == 'CLOSE' || ( MainButton  == 'AS' && IT ) ) || (auto_mation == 'MIS'  && OrderType && MainButton!='STRIKEPRICE') || (MainButton == 'CLOSE' && quantity) || (MainButton==='STRATEGY' && auto_mation!='' && tradingsymbol!='' && quantity!='') || ( MainButton==='STRIKEPRICE' && auto_mation!='FULLYBO' && auto_mation!='FULLYCO' && auto_mation!='' && Close_without_Value!='' && cal_put!='' && OrderType!='') || ( MainButton == 'ALGOCOBO' && auto_mation =='FULLYMIS' && OrderType!='' )"
                >
                  <h5 class="mt-2 border-left">PRODUCT
                      <span v-if="MainButton === 'CANCEL' || MainButton==='AS'" class="conditional text-danger" > ( Optional ) </span>
                  </h5>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 INTRADAY_child conditional"
                    :class="{ active: Producttype === 'INTRADAY' }" @click="ProducttypeC('INTRADAY')"
                  >
                    <span
                      class="buying-selling-word"
                      
                      >INTRADAY</span
                    >
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 CNC_child conditional"
                    :class="{ active: Producttype === 'CNC' }" @click="ProducttypeC('CNC')"
                  >
                    <span
                      class="buying-selling-word"
                      
                      >CNC</span
                    >
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 MARGIN_child conditional"
                    :class="{ active: Producttype === 'MARGIN' }"  @click="ProducttypeC('MARGIN')"
                  >
                    <span
                      class="buying-selling-word"
                     
                      >MARGIN</span
                    >
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 BO_child conditional"
                   :class="{ active: Producttype === 'BO' }"
                     v-if="(MainButton  == 'CANCEL' || MainButton  == 'CLOSE'|| MainButton  == 'AS')"
                  >
                    <input
                      type="radio"
                      name="product_type"
                      value="BO"
                      id="BO"
                    />
                    <span class="buying-selling-word"  @click="ProducttypeC('BO')">BO</span>
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 CO_child conditional"
                   v-if="(MainButton  == 'CANCEL' || MainButton  == 'CLOSE'|| MainButton  == 'AS')"
                  :class="{ active: Producttype === 'CO' }"
                  >
                    <input
                      type="radio"
                      name="product_type"
                      value="CO"
                      id="CO"
                      @click="ProducttypeC('CO')"
                    />
                    <span class="buying-selling-word" @click="ProducttypeC('CO')">CO</span>
                  </label>
                </div>
           
            <div
                  class="buying-selling-group conditional"
                  v-if=" ( MainButton  ==='STRIKEPRICE' && auto_mation != '' && OrderType!=''  &&quantity!='') " 
                >
                  <h5 class="mt-2 border-left">
                    NEAR BY
                    <span
                      class="conditional text-danger"
                      
                      style="display: none"
                    >
                    </span>
                  </h5>
                  <input
                    type="number"
                    name="near_by"
                    placeholder="NEARBY"
                    v-model="NEARBY"
                    id="NEARBY"
                  />
                </div>
                <div
                  class="buying-selling-group conditional"
                  v-if="NEARBY!=''"
                  
                >
                  <h5 class="mt-2 border-left">
                    CAL
                    <span
                      class="conditional text-danger"
                      
                     
                    >
                    </span>
                  </h5>
                  <input type="number" v-model="NEARBYCAL" name="cal" placeholder="cal" id="cal" />
                </div>
                <div
                  class="buying-selling-group conditional"
                  data-toggle="buttons"
                  v-if="NEARBYCAL!=''"
                 
                >
                  <h5 class="mt-2 border-left">
                    PLUS AND MINUS
                    <span
                      class="conditional text-danger"
                      
                      style="display: none"
                    >
                    </span>
                  </h5>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 +_child"
                    :class="{ active: cal_plus_minus === '+' }" @click="cal_plus_minusType('+')"
                  >
                    <input
                      type="radio"
                      v-model="cal_plus_minus"
                      name="cal_plus_minus"
                      value="+"
                      id="+"
                    />
                    <span class="buying-selling-word">+</span>
                  </label>
                  <label
                    class="btn btn-default drop_action_class buying-selling mt-1 -_child"
                    :class="{ active: cal_plus_minus === '-' }" @click="cal_plus_minusType('-')"
                  >
                    <input
                      type="radio"
                      name="cal_plus_minus"
                      value="-"
                      v-model="cal_plus_minus"
                      id="-"
                    />
                    <span class="buying-selling-word">-</span>
                  </label>
                </div>
            
            </div>
            <!-- ***************END ALICEBLUE************** -->
     
    

              <div
                class="row mt-3 conditional conditional-keyup"
               v-if="((MainButton == 'REGULAR' && Producttype!='') ) || (MainButton == 'CO' && (SL || LTP)) || (MainButton == 'BO' &&  SL!='') || MainButton == 'CANCEL' || ( MainButton  == 'AS' && (tradingsymbol||IT) ) || MainButton == 'CLOSE' || cal_plus_minus  || (MainButton == 'STRATEGY' && Producttype) || ( MainButton  == 'STRATEGY' && (SL || TP ) ) || (( MainButton == 'ALGOCOBO' && (auto_mation =='FULLYBO' ||auto_mation =='FULLYCO') && OrderType!='' && SL!='' ||  MainButton == 'ALGOCOBO' && auto_mation =='FULLYMIS' && OrderType!='' && Producttype!='' )) " 
              >
                <div class="col-12 boxcodes">
                  <button
                    type="button"
                    @click="Generate_Code(active_el)"
                    class="btn btn-success generate_code"
                  >
                    Generate Code
                  </button>
                </div>
              </div>



            </div>
          </div>
        </div>
      </div>

     <v-easy-dialog></v-easy-dialog>
      <!-- <v-easy-dialog v-model="simpleDialog"> -->
        <div v-if="simpleDialog"
          id="generated_code"
          class="modal fade show" role="dialog"
          style="padding-right: 17px; display: block"
        >
          <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-body">
                <p class="send_message_to"></p>
                <h5 class="namea">Generated Code</h5>
                <p
                  class="working_code d-block"
                  style="word-break: break-all; display: none"
                >
               
                  {{output}}
                </p>
                <p></p>
              </div>
              <div class="modal-footer">
                <p class="copy_message" style="display: none">
                  SUCCESSFULLY COPY
                </p>
                <button
                  type="button"
                  class="btn btn-success d-block"
                  style="float: left; display: none"
                  @click="copyToClipboard ('.working_code')"
                >
                  COPY CODE
                </button>
                <button
                  type="button"
                  class="btn btn-danger"
                  data-dismiss="modal"
                  @click="simpleDialog = false"
                >
                  Close
                </button>
              </div>
            </div>
          </div>

        </div>
      <!-- </v-easy-dialog> -->
    </section>
    <hr id="scroll_tobottom" />
  </div>
</template>

<script>
import VEasyDialog from "v-easy-dialog";
global.jQuery = require('jquery');
var $ = global.jQuery;
window.$ = $;
export default {
  name: "Syntax",
  components: {
    VEasyDialog,
  },

  props: {
    msg: String,
  },

  data: () => {
    return {
      active_el: "FYERSV2",
      MainButton: "",     
      tradingsymbol: "",
      quantitypercentage: "",
      quantity: "",
      Transaction: "",
      OrderType: "",
      Fund: "",
      LEVERAGE: "",
      Producttype: "",
      simpleDialog: false,
      TRPpercentage: "",
      LTPpercentage: "",
      TPpercentage: "",
      SLpercentage:"",
      LTP: "",
      SL: "",
      TP: "",
      TRP:'',
      auto_mation:'',
      NEARBY:'',
NEARBYCAL:'',
cal_plus_minus :'',
PER_LOT_SIZE:'',
 output : "[{",
 Close_without_Value:"",
 IsGClick:false,
 cal_put:"",
 IT:"",
NSE:"",
BSE:"",
exchange:"",

    };
  },
  methods: {
    ActiveTab(liname) {
        this.tradingsymbol="";
        this.IT="";
this.NSE="";
this.BSE="";
this.exchange="";
this.auto_mation="";
        this.NEARBY="";
        this.NEARBYCAL="";
        this.cal_plus_minus="";
        this.IsGClick=false,
      this.tradingsymbol= "";
      this.quantitypercentage= "";
      this.quantity= "";
      this.Transaction= "";
      this.OrderType= "";
      this.Fund= "";
      this.LEVERAGE= "";
      this.Producttype= "";
      this.simpleDialog= false;
      this.TRPpercentage= "";
      this.LTPpercentage= "";
      this.TPpercentage= "";
      this.SLpercentage="";
      this.LTP= "";
      this.SL= "";
      this.TP= "";
      this.MainButton="";
      this.Close_without_Value=""
      this.cal_put="";
      this.active_el = liname;
    },
    
    MainVaritey(name) {
    
       this.tradingsymbol="";
       this.IT="";
this.NSE="";
this.BSE="";
this.exchange="";
this.auto_mation="";
       this.NEARBY="";
        this.NEARBYCAL="";
        this.cal_plus_minus="";
       this.IsGClick=false,
      this.tradingsymbol= "";
      this.quantitypercentage= "";
      this.quantity= "";
      this.Transaction= "";
      this.OrderType= "";
      this.Fund= "";
      this.LEVERAGE= "";
      this.Producttype= "";
      this.simpleDialog= false;
      this.TRPpercentage= "";
      this.LTPpercentage= "";
      this.TPpercentage= "";
      this.SLpercentage="";
      this.LTP= "";
      this.SL= "";
      this.TP= "";
      this.Close_without_Value=""
      this.cal_put="";
      this.MainButton = name;
      console.log(this.MainButton);
    },
    TransactionType(name) {
      this.Transaction = name;
    },
    exchangeClick(name){
      this.exchange=name;
    },
    CAL_PUT_SELECTION(name){
      this.cal_put=name;
    },
    Close_without_Type (name){
      this.Close_without_Value=name;
    },
    OrderTypeChange(name) {
      this.OrderType = name;
    },
    FundType(name) {
      this.Fund = name;
    },
    ProducttypeC(name) {
      this.Producttype = name;
    },
    AutomationChange(name){
      this.auto_mation=name;
    },
    cal_plus_minusType(name){
      this.cal_plus_minus=name;
    },
    QuantityPercentageChange(event) {
      if (event.target.checked) {
        this.quantitypercentage = "%";
      } else {
        this.quantitypercentage = "";
      }
    },

    TRPpercentageChange(event) {
      if (event.target.checked) {
        this.TRPpercentage = "%";
      } else {
        this.TRPpercentage = "";
      }
    },
    LTPpercentageChange(event) {
      if (event.target.checked) {
        this.LTPpercentage = "%";
      } else {
        this.LTPpercentage = "";
      }
    },
    TPpercentageChange(event) {
      if (event.target.checked) {
        this.TPpercentage = "%";
      } else {
        this.TPpercentage = "";
      }
    },

     SLpercentageChange(event) {
      if (event.target.checked) {
        this.SLpercentage = "%";
      } else {
        this.SLpercentage = "";
      }
    },
  Generate_Code(version){
  //eslint-disable-next-line no-console 
  

  // Creating Local variable I dnt know why they are using so much so following same formula
var  LTPT=""
var TRPT=""
var  SLT =""
var TPT="";
var quantityT=this.quantity;

  this.IsGClick=true;
   this.output ="";
    this.output  ="[{";
    var quantitypercentage = '' ; 
    if(this.quantitypercentage!=''){
        quantityT = this.quantity+'%';
        if(this.Fund!=''){
          quantitypercentage += '"FUND":"'+this.Fund+'",';
        }
        if(this.LEVERAGE!=''){
         quantitypercentage += '"LEVERAGE":"'+this.LEVERAGE+'X",' ;
        }
        if(this.PER_LOT_SIZE!=''){
         quantitypercentage += '"PER_LOT_SIZE":"'+this.PER_LOT_SIZE+'",';
        }
      }
     
     if(version!='ALICEBLUE')
     {
       
    switch(this.MainButton) {
        case 'REGULAR':
              switch(this.OrderType) {
                case 'MARKET':
                this.output +=  '"TT":"'+this.Transaction+'","TS":"'+this.tradingsymbol+'","Q":"'+quantityT+'",'+quantitypercentage+'"OT":"'+this.OrderType+'","P":"'+this.Producttype+'","VL":"DAY"';
                break;
                case 'LIMIT':
                  LTPT = this.prtp(this.Transaction,this.LTP,this.LTPpercentage,'-','+');
                this.output +=  '"TT":"'+this.Transaction+'","TS":"'+this.tradingsymbol+'","Q":"'+quantityT+'",'+quantitypercentage+'"OT":"'+this.OrderType+'","LTP":"'+LTPT+'","P":"'+this.Producttype+'","VL":"DAY"';
                break;
                case 'SLM':
                 TRPT = this.prtp(this.Transaction,this.TRP,this.TPpercentage,'+','-');
                     this.output +=  '"TT":"'+this.Transaction+'","TS":"'+this.tradingsymbol+'","Q":"'+quantityT+'",'+quantitypercentage+'"OT":"'+this.OrderType+'","TRP":"'+this.TRP+'","P":"'+this.Producttype+'","VL":"DAY"';
                break;
                case 'SLL':
                 LTPT = this.prtp(this.Transaction,this.LTP,this.LTPpercentage,'+','-'); 
                 TRPT = this.prtp(this.Transaction,this.TRP,this.TPpercentage,'+','-');
                     this.output +=  '"TT":"'+this.Transaction+'","TS":"'+this.tradingsymbol+'","Q":"'+quantityT+'",'+quantitypercentage+'"OT":"'+this.OrderType+'","LTP":"'+LTPT+'","TRP":"'+TRPT+'","P":"'+this.Producttype+'","VL":"DAY"';
                break;
              }
        break;
        case 'CO':
           switch (this.OrderType) {
               case 'MARKET':
                   SLT = this.prtp(this.Transaction ,this.SL,this.SLpercentage , '-', '+');
                   this.output += '"TT":"' + this.Transaction + '","TS":"' + this.tradingsymbol + '","Q":"' + quantityT + '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"-0","SL":"' + SLT + '","P":"' + this.MainButton + '","VL":"DAY"';
                   break;
               case 'LIMIT':
                    SLT = this.prtp(this.Transaction, this.SL, this.SLpercentage, '-', '+');
                    LTPT = this.prtp(this.Transaction, this.LTP, this.LTPpercentage, '-', '+');
                   this.output += '"TT":"' + this.Transaction + '","TS":"' + this.tradingsymbol+ '","Q":"' + quantityT + '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"' + LTPT + '","SL":"' + SLT + '","P":"' + this.MainButton + '","VL":"DAY"';
                   break;
               case 'SLM':
                    TRPT = this.prtp(this.Transaction, this.TRP, this.TRPpercentage, '+', '-');
                    SLT = this.prtp(this.Transaction, this.SL, this.SLpercentage, '-', '+');
                   this.output += '"TT":"' + this.Transaction + '","TS":"' + this.tradingsymbol + '","Q":"' + quantityT  + '",' + quantitypercentage + '"OT":"' + this.OrderType + '","SL":"' + SLT + '","TRP":"' + TRPT + '","P":"' + this.MainButton + '","VL":"DAY"';
                   break;
               case 'SLL':
                     LTPT = this.prtp(this.Transaction, this.LTP, this.LTPpercentage, '+', '-');
                    TRPT = this.prtp(this.Transaction, this.TRP, this.TRPpercentage, '-', '+');
                    SLT = this.prtp(this.Transaction, this.SL, this.SLpercentage, '-', '+');
                   this.output += '"TT":"' + this.Transaction + '","TS":"' + this.tradingsymbol + '","Q":"' + quantityT  + '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"' + LTPT + '","SL":"' + SLT + '","TRP":"' + TRPT + '","P":"' + this.MainButton+ '","VL":"DAY"';
                   break;
            }
        break;
        case 'BO':
                                TPT = this.prtp(this.Transaction , this.TP, this.TPpercentage);
                                SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage );
                                switch (this.OrderType) {
                                    case 'MARKET':
                                        this.output += '"TT":"' + this.Transaction  + '","TS":"' + this.tradingsymbol + '","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","SL":"' + SLT + '","TP":"' + TPT + '","P":"' + this.MainButton + '","VL":"DAY"';
                                        break;
                                    case 'LIMIT':
                                        LTPT = this.prtp(this.Transaction , this.LTP,this.LTPpercentage, '-', '+');
                                        this.output += '"TT":"' + this.Transaction  + '","TS":"' + this.tradingsymbol + '","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"' + LTPT + '","SL":"' + SLT + '","TP":"' + TPT + '","P":"' + this.MainButton + '","VL":"DAY"';
                                        break;
                                    case 'SLM':
                                        TRPT = this.prtp(this.Transaction ,this.TRP ,this.TRPpercentage , '+', '-');
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage );
                                        this.output += '"TT":"' + this.Transaction  + '","TS":"' + this.tradingsymbol + '","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","TP":"' + TPT + '","SL":"' + SLT + '","TRP":"' + TRPT + '","P":"' + this.MainButton + '","VL":"DAY"';
                                        break;
                                    case 'SLL':
                                        LTPT = this.prtp(this.Transaction , this.LTP,this.LTPpercentage, '+', '-');
                                        TRPT = this.prtp(this.Transaction , this.TRP , this.TRPpercentage , '-', '+');
                                        this.output += '"TT":"' + this.Transaction  + '","TS":"' + this.tradingsymbol + '","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"' + LTPT + '","TRP":"' + TRPT + '","SL":"' + SLT + '","TP":"' + TPT + '","P":"' + this.MainButton + '","VL":"DAY"';
                                        break;
                                }
                                break;
                            case 'CANCEL':
                                this.output += '"CANCEL":"CANCEL"';
                                if (this.tradingsymbol) {
                                    this.output += ',"TS":"' + this.tradingsymbol + '"';
                                }
                                if (this.Transaction ) {
                                    this.output += ',"TT":"' + this.Transaction  + '"';
                                }
                                if ( this.Producttype) {
                                    this.output += ',"P":"' +this.Producttype+ '"';
                                }
                                break;
                            case 'FULLYALGO':
                                switch (this.auto_mation) {
                                    case 'FULLYMIS':
                                        this.output += '"CLOSE":"CLOSE","TS":"' + this.tradingsymbol + '","P":"' +this.Producttype+ '","AT":"' + version + '"},<br/>';
                                        this.output += '{"TT":"' + this.Transaction  + '","TS":"' + this.tradingsymbol + '","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","P":"' +this.Producttype+ '","VL":"DAY"';
                                        break;
                                    case 'FULLYBO':
                                        TPT = this.prtp(this.Transaction , this.TP, this.TPpercentage);
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage );
                                        this.output += '"CLOSE":"CLOSE","TS":"' + this.tradingsymbol + '","P":"BO","VL":"DAY","AT":"' + version + '"},<br/>{"TT":"' + this.Transaction  + '","TS":"' + this.tradingsymbol + '","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","SL":"' + SLT + '","TP":"' + TPT + '","P":"BO","VL":"DAY"';
                                        break;
                                    case 'FULLYCO':
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage , '-', '+');
                                        this.output += '"CLOSE":"CLOSE","TS":"' + this.tradingsymbol + '","P":"CO","VL":"DAY","AT":"' + version + '"},<br/>{"TT":"' + this.Transaction  + '","TS":"' + this.tradingsymbol + '","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"-0","SL":"' + SLT + '","P":"CO","VL":"DAY"';
                                        break;
                                    default:
                                        break;
                                }
                                break;
                            case 'CLOSE':
                                this.output += '"CLOSE":"CLOSE"';
                                if (this.tradingsymbol) {
                                    this.output += ',"TS":"' + this.tradingsymbol + '"';
                                }
                                if (quantityT) {
                                    this.output += ',"Q":"' +quantityT+ '"';
                                }
                                if (this.quantitypercentage  && this.PER_LOT_SIZE) {
                                    this.output += ',"PER_LOT_SIZE":"' + this.PER_LOT_SIZE + '"';
                                }
                                if (this.Transaction ) {
                                    this.output += ',"TT":"' + this.Transaction  + '"';
                                }
                                if (this.Producttype) {
                                    this.output += ',"P":"' +this.Producttype+ '"';
                                }
                                break;
                            case 'AS':
                                this.output += '"AS":"' + this.tradingsymbol + '"';
                                if (quantityT) {
                                    this.output += ',"Q":"' +quantityT+ '"';
                                }
                                if (this.quantitypercentage  &&  this.PER_LOT_SIZE) {
                                    this.output += ',"PER_LOT_SIZE":"' + this.PER_LOT_SIZE + '"';
                                }
                                if (this.Transaction ) {
                                    this.output += ',"TT":"' + this.Transaction  + '"';
                                }
                                if (this.Producttype) {
                                    this.output += ',"P":"' +this.Producttype+ '"';
                                }
                                //'+quantitypercentage+'

                                break;
                            case 'STRATEGY':
                                this.output += '"TT":"&#123;&#123;strategy.order.action&#125;&#125;","TS":"' + this.tradingsymbol + '","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"MARKET",';
                                switch (this.auto_mation) {
                                    case 'FULLYMIS':
                                        this.output += '"P":"' +this.Producttype+ '",';
                                        break;
                                    case 'FULLYBO':
                                        TPT = this.prtp(this.Transaction , this.TP, this.TPpercentage);
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage );
                                        this.output += '"TP":"' + this.TP + '","SL":"' + SLT + '","P":"BO",';
                                        break;
                                    case 'FULLYCO':
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage , '-', '+');
                                        this.output += '"LTP":"-0","SL":"' +SLT + '","P":"CO",';
                                        break;
                                       // this.output += '"VL":"DAY","PSIZE":"Z&#123;&#123;strategy.position_size&#125;&#125;","STRATEGY":"STRATEGY"';
                                }
                                this.output += '"VL":"DAY","PSIZE":"Z&#123;&#123;strategy.position_size&#125;&#125;","STRATEGY":"STRATEGY"';
                                break;
                            case 'STRIKEPRICE':
                                if (this.Close_without_Value == 'with_close') {
                                    this.output += '"AS":"' + this.tradingsymbol + '"';
                                    if (this.auto_mation== "FULLYMIS") {
                                        this.output += ',"P":"' +this.Producttype+ '"';
                                    }
                                    if (this.auto_mation== "FULLYCO") {
                                        this.output += ',"P":"CO"';
                                    }
                                    if (this.auto_mation== "FULLYBO") {
                                        this.output += ',"P":"BO"';
                                    }
                                    this.output += ',"AT":"' + version + '"},<br/>{';
                                }
                                this.output += '"TT":"' + this.Transaction  + '","TS":"' + this.tradingsymbol + '&#123;&#123;&#123;close&#125;&#125;&#125;' +  this.cal_put + '","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '",';
                                switch (this.auto_mation) {
                                    case 'FULLYMIS':
                                        if (this.OrderType == 'LIMIT') {
                                            LTPT = this.prtp(this.Transaction , this.LTP,this.LTPpercentage, '-', '+');
                                            this.output += '"LTP":"' + LTPT + '",';
                                        }
                                        this.output += '"P":"' +this.Producttype+ '",';
                                        break;
                                    case 'FULLYBO':
                                        if (this.OrderType == 'LIMIT') {
                                            LTPT = this.prtp(this.Transaction , this.LTP,this.LTPpercentage, '-', '+');
                                            this.output += '"LTP":"' + LTPT + '",';
                                        }
                                        TPT = this.prtp(this.Transaction , this.TP, this.TPpercentage);
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage );
                                        this.output += '"TP":"' + TPT + '","SL":"' + SLT + '","P":"BO",';
                                        break;
                                    case 'FULLYCO':
                                        if (this.OrderType == 'LIMIT') {
                                            LTPT = this.prtp(this.Transaction , this.LTP,this.LTPpercentage, '-', '+');
                                            this.output += '"LTP":"' + LTPT + '",';
                                        } else {
                                            this.output += '"LTP":"-0",'
                                        }
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage , '-', '+');
                                        this.output += '"SL":"' + SLT + '","P":"CO",';
                                        break;
                                    default:
                                        break;
                                }
                                this.output += '"VL":"DAY","NEAR":"' + this.NEARBY + '","CAL":"' +this.cal_plus_minus  +this.NEARBYCAL + '"';
                                break;
                            default:
    }
     }
     else{
       switch(this.MainButton) {
        case 'REGULAR':
              switch(this.OrderType) {
                case 'MARKET':
                this.output +=  '"TT":"'+this.Transaction+'","E":"'+this.exchange+'","Q":"'+quantityT+'",'+quantitypercentage+'"OT":"'+this.OrderType+'","P":"'+this.Producttype+'","VL":"DAY"';
                break;
                case 'LIMIT':
                LTPT = this.prtp(this.Transaction,this.LTP,this.LTPpercentage,'-','+');
                this.output +=  '"TT":"'+this.Transaction+'","E":"'+this.exchange+'","Q":"'+quantityT+'",'+quantitypercentage+'"OT":"'+this.OrderType+'","LTP":"'+LTPT+'","P":"'+this.Producttype+'","VL":"DAY"';
                break;
                case 'SLM':
              TRPT = this.prtp(this.Transaction,this.TRP,this.TPpercentage,'+','-');
                     this.output +=  '"TT":"'+this.Transaction+'","E":"'+this.exchange+'","Q":"'+quantityT+'",'+quantitypercentage+'"OT":"'+this.OrderType+'","TRP":"'+TRPT+'","P":"'+this.Producttype+'","VL":"DAY"';
                break;
                case 'SLL':
                LTPT = this.prtp(this.Transaction,this.LTP,this.LTPpercentage,'+','-'); this.TRP = this.prtp(this.Transaction,this.TRP,this.TPpercentage,'+','-');
                     this.output +=  '"TT":"'+this.Transaction+'","E":"'+this.exchange+'","Q":"'+quantityT+'",'+quantitypercentage+'"OT":"'+this.OrderType+'","LTP":"'+LTPT+'","TRP":"'+TRPT+'","P":"'+this.Producttype+'","VL":"DAY"';
                break;
              }
        break;
        case 'CO':
           switch (this.OrderType) {
               case 'MARKET':
                   SLT = this.prtp(this.Transaction ,this.SL,this.SLpercentage , '-', '+');
                   this.output += '"TT":"' + this.Transaction + '","E":"'+this.exchange+'","Q":"' +quantityT + '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"-0","SL":"' + SLT + '","P":"' + this.MainButton + '","VL":"DAY"';
                   break;
               case 'LIMIT':
                   SLT = this.prtp(this.Transaction, this.SL, this.SLpercentage, '-', '+');
                  LTPT = this.prtp(this.Transaction, this.LTP, this.LTPpercentage, '-', '+');
                   this.output += '"TT":"' + this.Transaction + '","E":"'+this.exchange+'","Q":"' + quantityT + '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"' + LTPT + '","SL":"' + SLT + '","P":"' + this.MainButton + '","VL":"DAY"';
                   break;
               case 'SLM':
                   TRPT = this.prtp(this.Transaction, this.TRP, this.TRPpercentage, '+', '-');
                   SLT = this.prtp(this.Transaction, this.SL, this.SLpercentage, '-', '+');
                   this.output += '"TT":"' + this.Transaction + '","E":"'+this.exchange+'","Q":"' + quantityT  + '",' + quantitypercentage + '"OT":"' + this.OrderType + '","SL":"' + SLT + '","TRP":"' + TRPT + '","P":"' + this.MainButton + '","VL":"DAY"';
                   break;
               case 'SLL':
                   LTPT = this.prtp(this.Transaction, this.LTP, this.LTPpercentage, '+', '-');
                   TRPT = this.prtp(this.Transaction, this.TRP, this.TRPpercentage, '-', '+');
                   SLT = this.prtp(this.Transaction, this.SL, this.SLpercentage, '-', '+');
                   this.output += '"TT":"' + this.Transaction + '","E":"'+this.exchange+'","Q":"' + quantityT  + '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"' + LTPT + '","SL":"' + SLT + '","TRP":"' + TRPT + '","P":"' + this.MainButton+ '","VL":"DAY"';
                   break;
            }
        break;
        case 'BO':
                                TPT = this.prtp(this.Transaction , this.TP, this.TPpercentage);
                                SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage );
                                switch (this.OrderType) {
                                    case 'MARKET':
                                        this.output += '"TT":"' + this.Transaction  + '","E":"'+this.exchange+'","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","SL":"' + SLT + '","TP":"' + TPT + '","P":"' + this.MainButton + '","VL":"DAY"';
                                        break;
                                    case 'LIMIT':
                                        LTPT = this.prtp(this.Transaction , this.LTP,this.LTPpercentage, '-', '+');
                                        this.output += '"TT":"' + this.Transaction  + '","E":"'+this.exchange+'","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"' + LTPT + '","SL":"' + SLT + '","TP":"' + TPT + '","P":"' + this.MainButton + '","VL":"DAY"';
                                        break;
                                    case 'SLM':
                                      TRPT = this.prtp(this.Transaction ,this.TRP ,this.TRPpercentage , '+', '-');
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage );
                                        this.output += '"TT":"' + this.Transaction  + '","E":"'+this.exchange+'","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","TP":"' + TPT + '","SL":"' + SLT + '","TRP":"' + TRPT + '","P":"' + this.MainButton + '","VL":"DAY"';
                                        break;
                                    case 'SLL':
                                        LTPT = this.prtp(this.Transaction , this.LTP,this.LTPpercentage, '+', '-');
                                        TRPT = this.prtp(this.Transaction , this.TRP , this.TRPpercentage , '-', '+');
                                        this.output += '"TT":"' + this.Transaction  + '","E":"'+this.exchange+'","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"' + LTPT + '","TRP":"' + TRPT + '","SL":"' + SLT + '","TP":"' + TPT + '","P":"' + this.MainButton + '","VL":"DAY"';
                                        break;
                                }
                                break;
                            case 'CANCEL':
                                this.output += '"CANCEL":"CANCEL"';
                                if (this.IT) {
                                    this.output += ',"TS":"' + this.IT + '"';
                                }
                                if (this.Transaction ) {
                                    this.output += ',"TT":"' + this.Transaction  + '"';
                                }
                                if ( this.Producttype) {
                                    this.output += ',"P":"' +this.Producttype+ '"';
                                }
                                break;
                            case 'FULLYALGO':
                                switch (this.auto_mation) {
                                    case 'FULLYMIS':
                                        this.output += '"CLOSE":"CLOSE","E":"'+this.exchange+'","P":"' +this.Producttype+ '","AT":"' + version + '"},<br/>';
                                        this.output += '{"TT":"' + this.Transaction  + '","E":"'+this.exchange+'","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","P":"' +this.Producttype+ '","VL":"DAY"';
                                        break;
                                    case 'FULLYBO':
                                        TPT = this.prtp(this.Transaction , this.TP, this.TPpercentage);
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage );
                                        this.output += '"CLOSE":"CLOSE","E":"'+this.exchange+'","P":"BO","VL":"DAY","AT":"' + version + '"},<br/>{"TT":"' + this.Transaction  + '","E":"'+this.exchange+'","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","SL":"' + SLT + '","TP":"' + TPT + '","P":"BO","VL":"DAY"';
                                        break;
                                    case 'FULLYCO':
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage , '-', '+');
                                        this.output += '"CLOSE":"CLOSE","E":"'+this.exchange+'","P":"CO","VL":"DAY","AT":"' + version + '"},<br/>{"TT":"' + this.Transaction  + '","E":"'+this.exchange+'","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '","LTP":"-0","SL":"' + SLT + '","P":"CO","VL":"DAY"';
                                        break;
                                    default:
                                        break;
                                }
                                break;
                            case 'CLOSE':
                                this.output += '"CLOSE":"CLOSE"';
                                if (this.tradingsymbol) {
                                    this.output += ',"E":"'+this.exchange+'"';
                                }
                                if (quantityT) {
                                    this.output += ',"Q":"' +quantityT+ '"';
                                }
                                if (this.quantitypercentage  && this.PER_LOT_SIZE) {
                                    this.output += ',"PER_LOT_SIZE":"' + this.PER_LOT_SIZE + '"';
                                }
                                if (this.Transaction ) {
                                    this.output += ',"TT":"' + this.Transaction  + '"';
                                }
                                if (this.Producttype) {
                                    this.output += ',"P":"' +this.Producttype+ '"';
                                }
                                break;
                            case 'AS':
                                this.output += '"AS":"' + this.tradingsymbol + '"';
                                if (quantityT) {
                                    this.output += ',"Q":"' +quantityT+ '"';
                                }
                                if (this.quantitypercentage  &&  this.PER_LOT_SIZE) {
                                    this.output += ',"PER_LOT_SIZE":"' + this.PER_LOT_SIZE + '"';
                                }
                                if (this.Transaction ) {
                                    this.output += ',"TT":"' + this.Transaction  + '"';
                                }
                                if (this.Producttype) {
                                    this.output += ',"P":"' +this.Producttype+ '"';
                                }
                                //'+quantitypercentage+'

                                break;
                            case 'STRATEGY':
                                this.output += '"TT":"&#123;&#123;strategy.order.action&#125;&#125;","TS":"' + this.tradingsymbol + '","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"MARKET",';
                                switch (this.auto_mation) {
                                    case 'FULLYMIS':
                                        this.output += '"P":"' +this.Producttype+ '",';
                                        break;
                                    case 'FULLYBO':
                                        TPT = this.prtp(this.Transaction , this.TP, this.TPpercentage);
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage );
                                        this.output += '"TP":"' + TPT + '","SL":"' + SLT + '","P":"BO",';
                                        break;
                                    case 'FULLYCO':
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage , '-', '+');
                                        this.output += '"LTP":"-0","SL":"' + SLT + '","P":"CO",';
                                        break;
                                       // this.output += '"VL":"DAY","PSIZE":"Z&#123;&#123;strategy.position_size&#125;&#125;","STRATEGY":"STRATEGY"';
                                }
                                this.output += '"VL":"DAY","PSIZE":"Z&#123;&#123;strategy.position_size&#125;&#125;","STRATEGY":"STRATEGY"';
                                break;
                            case 'STRIKEPRICE':
                                if (this.Close_without_Value == 'with_close') {
                                    this.output += '"AS":"' + this.exchange + '"';
                                    if (this.auto_mation== "FULLYMIS") {
                                        this.output += ',"P":"' +this.Producttype+ '"';
                                    }
                                    if (this.auto_mation== "FULLYCO") {
                                        this.output += ',"P":"CO"';
                                    }
                                    if (this.auto_mation== "FULLYBO") {
                                        this.output += ',"P":"BO"';
                                    }
                                    this.output += ',"AT":"' + version + '"},<br/>{';
                                }
                                this.output += '"TT":"' + this.Transaction  + '","IT":"' + this.IT + '&#123;&#123;&#123;close&#125;&#125;&#125;' +  this.cal_put + '","Q":"' +quantityT+ '",' + quantitypercentage + '"OT":"' + this.OrderType + '",';
                                switch (this.auto_mation) {
                                    case 'FULLYMIS':
                                        if (this.OrderType == 'LIMIT') {
                                            LTPT = this.prtp(this.Transaction , this.LTP,this.LTPpercentage, '-', '+');
                                            this.output += '"LTP":"' + LTPT + '",';
                                        }
                                        this.output += '"P":"' +this.Producttype+ '",';
                                        break;
                                    case 'FULLYBO':
                                        if (this.OrderType == 'LIMIT') {
                                            LTPT = this.prtp(this.Transaction , this.LTP,this.LTPpercentage, '-', '+');
                                            this.output += '"LTP":"' + LTPT + '",';
                                        }
                                        TPT = this.prtp(this.Transaction , this.TP, this.TPpercentage);
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage );
                                        this.output += '"TP":"' + TPT + '","SL":"' + SLT + '","P":"BO",';
                                        break;
                                    case 'FULLYCO':
                                        if (this.OrderType == 'LIMIT') {
                                            LTPT = this.prtp(this.Transaction , this.LTP,this.LTPpercentage, '-', '+');
                                            this.output += '"LTP":"' + LTPT + '",';
                                        } else {
                                            this.output += '"LTP":"-0",'
                                        }
                                        SLT = this.prtp(this.Transaction , this.SL, this.SLpercentage , '-', '+');
                                        this.output += '"SL":"' + SLT + '","P":"CO",';
                                        break;
                                    default:
                                        break;
                                }
                                this.output += '"VL":"DAY","NEAR":"' + this.NEARBY + '","CAL":"' +this.cal_plus_minus  +this.NEARBYCAL + '"';
                                break;
                            default:
    }
     }
     this.output += ',"AT":"'+version+'"}]';
    this.simpleDialog = true;
  },

 prtp(transition_type,value,percentage,opreator1,opreator2) {
   console.log("opreator1" +opreator1 +" value " +value+"percentage "+percentage+" opreator2 "+opreator2);

  
      if(!percentage){
        percentage = '';
      }
      if(!opreator1){
        opreator1 = '';
      }
      if(!opreator2){
        opreator2 = '';
      }
        if (transition_type == 'BUY'){ value = opreator1+value+percentage; }
    else{ value = opreator2+value+percentage; }
    return value; 
    },
  
// Popup
    ShowModal() {
      this.simpleDialog = true;
    },

    copyToClipboard(element) {
var $temp = $("<textarea>");
                var brRegex = /<br\s*[\\]?>/gi;
                $("body").append($temp);
                $temp.val($(element).html().replace(brRegex, "\r\n")).select();
                document.execCommand("copy");
                $temp.remove();
                $('.copy_message').html('SUCCESSFULLY COPY').css({
                    "display": "block",
                    "position": "absolute",
                    "left": "21px",
                    "margin-top": "-3px",
                    "color": "#00a000"
                });}
  },
};
</script>

<style>
.modal-mask {
  position: fixed;
  z-index: 9998;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: table;
  transition: opacity 0.3s ease;
}

.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
}

.modal-container {
  width: 300px;
  margin: 0px auto;
  padding: 20px 30px;
  background-color: #fff;
  border-radius: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.33);
  transition: all 0.3s ease;
  font-family: Helvetica, Arial, sans-serif;
}

.modal-header h3 {
  margin-top: 0;
  color: #42b983;
}

.modal-body {
  margin: 20px 0;
}

.modal-default-button {
  float: right;
}

/*
 * The following styles are auto-applied to elements with
 * transition="modal" when their visibility is toggled
 * by Vue.js.
 *
 * You can easily play with the modal transition by editing
 * these styles.
 */

.modal-enter {
  opacity: 0;
}

.modal-leave-active {
  opacity: 0;
}

.modal-enter .modal-container,
.modal-leave-active .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
.btn:not(:disabled):not(.disabled) {
    cursor: pointer;
}
.buying-selling {
    margin: 1px !important;
    /* position: relative; */
}
.btn-default {
    color: #333;
    background-color: #fff;
    border-color: #ccc;
}
.btn, a, button {
    text-decoration: none;
    outline: 0;
}
.mt-1, .my-1 {
    margin-top: .25rem!important;
}
</style>
