<template>
  <div id="app">
   
      <Syntax msg="Welcome to Syntax"/>
  </div>
</template>

<script>

import Syntax from './components/Syntax.vue'
global.jQuery = require('jquery');
var $ = global.jQuery;
window.$ = $;
export default {
  name: 'App',
  components: {    
    Syntax   
    
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  color: #2c3e50;
  /* margin-top: 60px; */
}
</style>
